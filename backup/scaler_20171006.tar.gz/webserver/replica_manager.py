import math, time, datetime, random, shutil, threading
from threading import Lock

class Replica_Manager:
    lock = Lock()
    replicas = {}
    index = 0

    def __init__(self):
        return

    def __str__(self):
        text = ""
        return text

    def register(self, client_address):
        self.lock.acquire()
        replica_id = -1
        try:
            # only one thread can execute code there
            replica_id = "REPLICA_" + str(self.index)
            self.index += 1
            now = time.time()
            replica = {'ip': client_address[0], 'port': client_address[1], 'registered_at':now, 'last_still_alive_at': now}
            self.replicas[replica_id] = replica
        finally:
            self.lock.release() #release lock
        print(self.replicas)
        return replica_id

    def still_alive(self,replica_id, data):
        # only one thread can execute code there
        now = time.time()
        self.replicas[replica_id]['last_still_alive_at'] = now
        print(self.replicas)
        return now

    def get_replicas(self):
        return self.replicas
