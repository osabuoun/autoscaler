#!/bin/sh
python3 ./webclient.py "$1"